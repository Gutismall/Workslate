package com.example.workslateapp.Callbacks

interface LocationCallback {
    fun onLocationResult(latitude: Double, longitude: Double)
}
package com.example.workslateapp.DataClasses

enum class ShiftType {
    MORNING, AFTERNOON, NIGHT
}
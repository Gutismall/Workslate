package com.example.workslateapp.DataClasses

data class User(
    var email: String,
    var firstName : String,
    var lastName : String,
    var phoneNumber: String,
    var companyCode: String,
)
